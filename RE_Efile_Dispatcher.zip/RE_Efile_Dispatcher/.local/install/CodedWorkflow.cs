using UiPath.CodedWorkflows;

namespace RE_Efile_Dispatcher
{
    public class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}