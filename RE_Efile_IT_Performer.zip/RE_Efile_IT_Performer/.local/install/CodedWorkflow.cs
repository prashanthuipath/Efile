using UiPath.CodedWorkflows;

namespace RE_Efile_IT_Performer
{
    public class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}